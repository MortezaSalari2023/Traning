﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace VPN.Migrations
{
    /// <inheritdoc />
    public partial class M3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_MyModel",
                table: "MyModel");

            migrationBuilder.RenameTable(
                name: "MyModel",
                newName: "Country");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Country",
                table: "Country",
                column: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_Country",
                table: "Country");

            migrationBuilder.RenameTable(
                name: "Country",
                newName: "MyModel");

            migrationBuilder.AddPrimaryKey(
                name: "PK_MyModel",
                table: "MyModel",
                column: "Id");
        }
    }
}
