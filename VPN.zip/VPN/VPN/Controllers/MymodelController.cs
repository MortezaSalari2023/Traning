﻿using VPN.Repo;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace VPN.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MymodelController : ControllerBase
    {
        private readonly ImodelRepo _repo;

        public MymodelController(ImodelRepo imodelRepo)
        {
                _repo = imodelRepo;
        }

        [HttpGet("GetAll")]
        public async Task<IActionResult> getAll()
        {
            return Ok(_repo.Getall());
        }

        [HttpPost("Add")]
        public async Task<IActionResult> insert(MymodelVM mymodelVM)
        {
            return Ok(_repo.insert(mymodelVM));
        }

        [HttpDelete("Delete")]
        public async Task<IActionResult> Delete(MymodelVM mymodelVM)
        {
            return Ok(_repo.Delete(mymodelVM));
        }
    }
}
