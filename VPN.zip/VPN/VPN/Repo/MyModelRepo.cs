﻿
using VPN.Models.DatabaseContext;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace VPN.Repo
{
    public interface ImodelRepo
    {
       public Task insert(MymodelVM mymodelVM);
       public Task<IEnumerable<MymodelVM>> Getall();
        public Task Delete (MymodelVM mymodelVM);
    }
    public class MyModelRepo : ImodelRepo
    {
        private readonly MyDbContext _dbContext;
        public MyModelRepo(MyDbContext myDbContext)
        {
            _dbContext = myDbContext;   
        }

        public Task Delete(MymodelVM mymodelVM)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<MymodelVM>> Getall()
        {
            return  _dbContext.Country.Select(p=>new MymodelVM { 
            ImageSrc=p.ImageSrc,
            Id=p.Id,
            CountryName=p.CountryName
            }).ToList();
        }


        public async Task insert(MymodelVM mymodelVM)
        {
            _dbContext.Country.Add(new Models.Entities.Country { 
            Id=mymodelVM.Id,
            CountryName=mymodelVM.CountryName,
            ImageSrc=mymodelVM.ImageSrc
            
            });
             _dbContext.SaveChanges();
        }


    }
}
