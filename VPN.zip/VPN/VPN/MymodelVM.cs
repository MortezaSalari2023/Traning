﻿namespace VPN
{
    public class MymodelVM
    {
        public int Id { get; set; }
        public string CountryName { get; set; }
        public string ImageSrc { get; set; }    
    }
}
